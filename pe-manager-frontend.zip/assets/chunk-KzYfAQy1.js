const o=async()=>{throw new Error("LLM integration not available in local mode")};export{o as I};
