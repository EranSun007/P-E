const n=r=>Array.isArray(r)?r:r==null?[]:[r];export{n as s};
