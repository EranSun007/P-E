#!/usr/bin/env node

/**
 * Import daily meeting markdown files into team_summaries table
 *
 * Usage:
 *   npm run import-dailies -- --path /path/to/dailies --team reporting
 *
 * Options:
 *   --path    Directory containing daily-meeting-YYYY-MM-DD.md files (required)
 *   --team    Team department name (default: 'reporting')
 *   --user    User ID for ownership (default: 'dev-user-001')
 *   --dry-run Show what would be imported without saving
 */

import fs from 'fs';
import path from 'path';
import TeamSummaryService from '../services/TeamSummaryService.js';

// Parse command line arguments
function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    path: null,
    team: 'reporting',
    user: '0cae427a-7fa9-4d76-8497-0646d338c96c', // Admin user UUID
    dryRun: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--path' && args[i + 1]) {
      options.path = args[++i];
    } else if (arg === '--team' && args[i + 1]) {
      options.team = args[++i];
    } else if (arg === '--user' && args[i + 1]) {
      options.user = args[++i];
    } else if (arg === '--dry-run') {
      options.dryRun = true;
    }
  }

  return options;
}

// Convert name to slug ID (e.g., "Dan/Ido" -> "dan-ido")
function slugify(name) {
  return name
    .toLowerCase()
    .replace(/[\/\\]/g, '-')  // Replace slashes with dashes
    .replace(/[^a-z0-9-]/g, '-')  // Replace non-alphanumeric with dashes
    .replace(/-+/g, '-')  // Collapse multiple dashes
    .replace(/^-|-$/g, '');  // Trim leading/trailing dashes
}

// Extract date from filename (daily-meeting-YYYY-MM-DD.md)
function extractDateFromFilename(filename) {
  const match = filename.match(/daily-meeting-(\d{4}-\d{2}-\d{2})\.md$/);
  return match ? match[1] : null;
}

// Parse a member section from markdown
function parseMemberSection(content) {
  const items = [];
  let completedCount = 0;
  let blockerCount = 0;
  let status = 'unknown';

  const lines = content.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();

    // Extract status from ### Status line
    const statusMatch = trimmed.match(/^###\s*Status\s*[-–—]\s*(.+)$/i);
    if (statusMatch) {
      status = statusMatch[1].trim();
      continue;
    }

    // Count completed items (✅ or "Done")
    if (trimmed.includes('✅') || /done/i.test(trimmed)) {
      completedCount++;
    }

    // Count blockers
    if (/\*\*blocker\*\*/i.test(trimmed) || /blocker:/i.test(trimmed)) {
      blockerCount++;
    }

    // Extract list items as work items
    if (trimmed.startsWith('-') || trimmed.startsWith('*')) {
      const itemText = trimmed.replace(/^[-*]\s*/, '').replace(/\*\*/g, '');
      if (itemText.length > 0 && !itemText.startsWith('#')) {
        const itemStatus = itemText.includes('✅') || /done/i.test(itemText) ? 'done' : 'in_progress';
        items.push({
          title: itemText.substring(0, 200),  // Limit length
          status: itemStatus
        });
      }
    }
  }

  // If status indicates done, set completedCount to at least 1
  if (/done/i.test(status) && completedCount === 0) {
    completedCount = 1;
  }

  return { items, completedCount, blockerCount, status };
}

// Parse a daily meeting markdown file
function parseDailyFile(content, date, teamDepartment) {
  const summaries = [];

  // Split by H2 headers (## Name - Project)
  const sections = content.split(/^## /m).slice(1);  // Skip content before first ##

  for (const section of sections) {
    const lines = section.split('\n');
    const headerLine = lines[0].trim();

    // Skip DevOps, ICC, and other non-person sections
    if (/^(DevOps|ICC|Notes|Action Items|General)/i.test(headerLine)) {
      continue;
    }

    // Parse header: "Dan/Ido - Ariba" or just "Dan"
    const headerMatch = headerLine.match(/^([^-\n]+?)(?:\s*[-–—]\s*(.+))?$/);
    if (!headerMatch) continue;

    const memberName = headerMatch[1].trim();
    const projectContext = headerMatch[2]?.trim() || '';

    // Skip empty names
    if (!memberName) continue;

    // Parse the section content
    const sectionContent = lines.slice(1).join('\n');
    const { items, completedCount, blockerCount, status } = parseMemberSection(sectionContent);

    // Build one-line summary
    let oneLine = projectContext;
    if (status && status !== 'unknown') {
      oneLine = oneLine ? `${oneLine} - ${status}` : status;
    }

    summaries.push({
      memberId: slugify(memberName),
      memberName,
      teamDepartment,
      weekEndingDate: date,
      completedCount,
      blockerCount,
      oneLine: oneLine || null,
      items,
      lastUpdateDays: 0
    });
  }

  return summaries;
}

// Main import function
async function importDailies(options) {
  const { path: dailiesPath, team, user, dryRun } = options;

  if (!dailiesPath) {
    console.error('Error: --path is required');
    console.log('Usage: npm run import-dailies -- --path /path/to/dailies --team reporting');
    process.exit(1);
  }

  // Verify path exists
  if (!fs.existsSync(dailiesPath)) {
    console.error(`Error: Path does not exist: ${dailiesPath}`);
    process.exit(1);
  }

  // Find all daily meeting files
  const files = fs.readdirSync(dailiesPath)
    .filter(f => f.match(/^daily-meeting-\d{4}-\d{2}-\d{2}\.md$/))
    .sort();

  if (files.length === 0) {
    console.error('No daily meeting files found (expected format: daily-meeting-YYYY-MM-DD.md)');
    process.exit(1);
  }

  console.log(`Found ${files.length} daily meeting files`);
  console.log(`Team: ${team}`);
  console.log(`User: ${user}`);
  console.log(`Dry run: ${dryRun}`);
  console.log('---');

  const service = new TeamSummaryService();
  let totalImported = 0;
  let totalErrors = 0;

  for (const filename of files) {
    const date = extractDateFromFilename(filename);
    if (!date) {
      console.warn(`Skipping ${filename}: could not extract date`);
      continue;
    }

    const filePath = path.join(dailiesPath, filename);
    const content = fs.readFileSync(filePath, 'utf-8');

    const summaries = parseDailyFile(content, date, team);

    console.log(`\n${filename} (${date}): ${summaries.length} members`);

    for (const summary of summaries) {
      console.log(`  - ${summary.memberName}: ${summary.completedCount} completed, ${summary.blockerCount} blockers`);

      if (!dryRun) {
        try {
          await service.create(user, summary);
          totalImported++;
        } catch (err) {
          console.error(`    Error saving ${summary.memberName}: ${err.message}`);
          totalErrors++;
        }
      } else {
        totalImported++;
      }
    }
  }

  console.log('\n---');
  console.log(`Import complete: ${totalImported} summaries ${dryRun ? 'would be ' : ''}imported, ${totalErrors} errors`);

  // Exit cleanly
  process.exit(totalErrors > 0 ? 1 : 0);
}

// Run
const options = parseArgs();
importDailies(options).catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
