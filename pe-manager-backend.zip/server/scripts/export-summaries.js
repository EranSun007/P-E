#!/usr/bin/env node

/**
 * Export team summaries from local database to JSON file
 * This can then be imported to production via the bulk API endpoint
 *
 * Usage:
 *   node server/scripts/export-summaries.js --team reporting --output summaries.json
 */

import pool, { query } from '../db/connection.js';

async function exportSummaries() {
  const args = process.argv.slice(2);
  let team = null;
  let output = 'summaries.json';

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--team' && args[i + 1]) {
      team = args[++i];
    } else if (args[i] === '--output' && args[i + 1]) {
      output = args[++i];
    }
  }

  const conditions = [];
  const values = [];
  let paramIndex = 1;

  if (team) {
    conditions.push(`team_department = $${paramIndex}`);
    values.push(team);
    paramIndex++;
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  const sql = `
    SELECT
      member_id as "memberId",
      member_name as "memberName",
      team_department as "teamDepartment",
      week_ending_date as "weekEndingDate",
      completed_count as "completedCount",
      blocker_count as "blockerCount",
      one_line as "oneLine",
      items,
      last_update_days as "lastUpdateDays"
    FROM team_summaries
    ${whereClause}
    ORDER BY week_ending_date, member_name
  `;

  const result = await query(sql, values);

  // Format dates as YYYY-MM-DD strings
  const summaries = result.rows.map(row => ({
    ...row,
    weekEndingDate: row.weekEndingDate instanceof Date
      ? row.weekEndingDate.toISOString().split('T')[0]
      : row.weekEndingDate
  }));

  const fs = await import('fs');
  fs.writeFileSync(output, JSON.stringify({ summaries }, null, 2));

  console.log(`Exported ${summaries.length} summaries to ${output}`);

  await pool.end();
}

exportSummaries().catch(err => {
  console.error('Export failed:', err);
  process.exit(1);
});
